from conn.server_main import Server

server = Server();
