"""
Recieves and processes requests from clients
"""
from conn.server_connection import ServerConnection;
from leaderboard import Leaderboard;

class Server:
    def __init__(self,
        no_socket = False,
    ):
        # Initialise server components
        self.leaderboard = Leaderboard();

        # Initialise internal state
        self.games = {};
        self.__clients = {};
        
    """
    Get list of game names
    """
    def get_games_keys(self):
        return self.games.keys();
    
    """
    Create a new server connection to a client
    """
    def create_client(self, socket = None):
        client = ServerConnection(
            server = self,
            socket = socket,
        );
        self.clients[client.id] = client;

    """
    Remove a client from server 
    """
    def disconnect(self, client):
        del self.clients[client.id];

    """
    Register a new game
    """
    def add_game(self, game,
        existing_game = "This game already exists",
        name_taken = "This game name is already taken",
    ):
        # Check if game or game name already exists
        if game.id in self.games:
            raise Exception(existing_game);

        searched_game = self.get_game(game.name, check_no_game = False);
        if searched_game is not None:
            raise Exception(name_taken);
        
        # Add game to server
        self.games[game.id] = game;
    
    """
    Get a game by name
    """
    def get_game(self, name,
        check_no_game = True,
        no_game = "No game with that name",
        multiple_games = "Multiple games with the same name",
    ):
        # Get all games with requested name
        games = [game for game in self.games.values() if game.name == name];        
        # Return errors if no game or multiple games found
        if len(games) == 0:
            if check_no_game:
                raise Exception(no_game);
            else:
                return None;

        if len(games) > 1:
            raise Exception(multiple_games);
        
        # Return only game found
        return games[0];

    """
    Send message to clients by player id
    """
    def send_to_players(self,
        players,
        message,
    ):
        clients = [client for client in self.clients.values() if client.player.id in players];

        [client.send(message) for client in clients];
